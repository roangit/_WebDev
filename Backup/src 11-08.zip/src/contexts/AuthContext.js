import { createContext, useState } from "react";

// criando contexo
export const AuthContext = createContext();

// criando provider
export const AuthContextProvider = ({children}) => {    
     const [isLogged, setIsLogged] = useState("true")
     return(
          <AuthContext.Provider  value={{isLogged, setIsLogged}}>
               {children}
          </AuthContext.Provider>
     );
};