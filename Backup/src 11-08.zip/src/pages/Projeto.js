import React from 'react'

//components
import MainHeader from '../components/MainHeader';

const Projeto = () => {
  return (
     <div className="container">
          <div className="Header">
          <MainHeader titulo='Projetos'></MainHeader>  
          </div>
          <div className="VertMenu">
          </div>
          <div className="Main">
               Centro
          </div>
          <div className="Footer"></div>
     </div>
  )
}

export default Projeto